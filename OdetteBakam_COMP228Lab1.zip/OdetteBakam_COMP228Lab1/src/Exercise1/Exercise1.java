package Exercise1;

public class Exercise1 {
}
